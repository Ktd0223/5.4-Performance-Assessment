Kai Draper Wk 5 Performance Assessment

SETUP (XAMPP / Windows)
1. Extract this ZIP.
2. Copy the Draper_wk5pa folder into C:\xampp\htdocs\
   The file must be at C:\xampp\htdocs\Draper_wk5pa\data_entry.php
   Avoid nesting another Draper_wk5pa folder inside it.
3. Open XAMPP Control Panel and start Apache. MySQL is not needed.
4. Open http://localhost/Draper_wk5pa/data_entry.php
   Use Apache to run the PHP files, rather than VS Code Live Server.
   PHP 7.3 or newer is required (PHP 8.x recommended).

FILES
data_entry.php   - Saves name in a 30-day cookie and birth date in a session.
data_display.php - Displays the cookie and session data.
styles.css      - Shared appearance for both pages.

MANUAL CHECK
1. Open data_entry.php before entering information: both inputs are empty.
2. Enter a name and a birth date in YYYY-MM-DD format, then click Submit.
3. Check that both fields are filled after the page reloads.
4. Follow View stored information. Check that both values are displayed.
5. Follow Back to data entry. Check that both fields retain the values.
6. Change the values and submit again. Check that both pages show the changes.
7. Open the display page in a separate private browser session: no data saved.

The name cookie lasts 30 days. The date of birth lasts for the session,
subject to the browser's session handling and PHP's session cleanup settings.
Both pages escape saved values before displaying them as HTML.
