<?php
session_start();
$name = isset($_COOKIE['name']) && is_string($_COOKIE['name']) ? $_COOKIE['name'] : '';
$dateOfBirth = isset($_SESSION['date_of_birth']) && is_string($_SESSION['date_of_birth']) ? $_SESSION['date_of_birth'] : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kai Draper Wk 5 Performance Assessment</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<main>
    <h1>Kai Draper Wk 5 Performance Assessment</h1>
    <h2>Data Display</h2>
    <p>Your information from the name cookie and date of birth session.</p>
    <dl>
        <dt>Name</dt>
        <dd><?= $name === '' ? 'No name has been saved.' : htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?></dd>
        <dt>Date of Birth</dt>
        <dd><?= $dateOfBirth === '' ? 'No date of birth has been saved.' : htmlspecialchars($dateOfBirth, ENT_QUOTES, 'UTF-8') ?></dd>
    </dl>
    <a href="data_entry.php">&larr; Back to data entry</a>
</main>
</body>
</html>
