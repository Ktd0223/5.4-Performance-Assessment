<?php
// Start the session before sending any HTML to the browser.
session_start();
$error = '';
$name = isset($_COOKIE['name']) && is_string($_COOKIE['name']) ? $_COOKIE['name'] : '';
$dateOfBirth = isset($_SESSION['date_of_birth']) && is_string($_SESSION['date_of_birth']) ? $_SESSION['date_of_birth'] : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = isset($_POST['name']) && is_string($_POST['name']) ? trim($_POST['name']) : '';
    $dateOfBirth = isset($_POST['date_of_birth']) && is_string($_POST['date_of_birth']) ? trim($_POST['date_of_birth']) : '';
    $date = DateTime::createFromFormat('!Y-m-d', $dateOfBirth);

    if ($name === '' || strlen($name) > 200) {
        $error = 'Please enter a name of 200 bytes or fewer.';
    } elseif (!$date || $date->format('Y-m-d') !== $dateOfBirth || $dateOfBirth > date('Y-m-d')) {
        $error = 'Please enter a valid date of birth in YYYY-MM-DD format that is not in the future.';
    } else {
        // The name persists for 30 days. No HTML may appear before setcookie().
        setcookie('name', $name, [
            'expires' => time() + (30 * 24 * 60 * 60),
            'path' => rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/') . '/',
            'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
            'httponly' => true,
            'samesite' => 'Lax'
        ]);
        // The date of birth stays on the server in this browser's session.
        $_SESSION['date_of_birth'] = $dateOfBirth;
        $_SESSION['saved_message'] = 'Your information was saved.';
        // Reload so the form reads the newly stored cookie from the browser.
        header('Location: data_entry.php', true, 303);
        exit;
    }
}
$message = $_SESSION['saved_message'] ?? '';
unset($_SESSION['saved_message']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kai Draper Wk 5 Performance Assessment</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<main>
    <h1>Kai Draper Wk 5 Performance Assessment</h1>
    <h2>Data Entry</h2>
    <p>Enter your name and date of birth, then select Submit.</p>
    <?php if ($error !== ''): ?>
        <p class="error" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
    <?php endif; ?>
    <?php if ($message !== ''): ?>
        <p class="success" role="status"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></p>
    <?php endif; ?>
    <form action="data_entry.php" method="post">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" maxlength="200" required autocomplete="name"
               value="<?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>">
        <label for="date_of_birth">Date of Birth</label>
        <input type="text" id="date_of_birth" name="date_of_birth" required maxlength="10"
               placeholder="YYYY-MM-DD" pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" aria-describedby="date_help"
               value="<?= htmlspecialchars($dateOfBirth, ENT_QUOTES, 'UTF-8') ?>">
        <small id="date_help">Use YYYY-MM-DD, for example 2000-01-15.</small>
        <button type="submit">Submit</button>
    </form>
    <a href="data_display.php">View stored information &rarr;</a>
</main>
</body>
</html>
